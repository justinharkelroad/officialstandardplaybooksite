# The Agency AI Install: Starter Pack

Welcome. This pack gives your brain a head start so build time is build time.

## What to do (part of your pre-work, takes 5 minutes)

1. Create your workspace folder on your computer if you have not already (suggested name: MY BIZ BRAIN).
2. Copy everything in this pack INTO that folder, keeping the structure:
   - `memory/glossary.md` goes in a `memory` folder
   - `current-projects/_project-template.md` goes in a `current-projects` folder
   - `working-preferences-STARTER.md` and `CLAUDE-STARTER.md` sit at the root
3. Add your gathered materials to the same folder (writing samples, team roster, project list, agency facts, tools list).
4. Open the folder in Cowork (or Codex) once. Done. That is the screenshot you send Mary.

## What NOT to do

- Do not fill any of this in by hand. We do that together, live, with the brain doing the typing.
- Do not rename the files. The workshop prompts reference them by name.
- Do not put raw exports or data dumps in the folder. Exports stay on your desktop; the brain points at them when it needs to analyze. The folder keeps conclusions, not databases.

## What is in the pack

| File | What it is |
|---|---|
| `CLAUDE-STARTER.md` | The skeleton of your master file. Becomes `CLAUDE.md` in Phase 7 (or `AGENTS.md` on the Codex track). |
| `working-preferences-STARTER.md` | Your rules of engagement, with the four safety rules pre-written. Customized in Phase 3. |
| `memory/glossary.md` | About 30 insurance terms, pre-loaded. You cut, correct, and add in Phase 7. |
| `current-projects/_project-template.md` | The shape of a project file. Phase 6 builds your real ones from it. |

See you in the room.
