# AI Install

AI Install v2.0.0 walks an insurance agency owner through building an AI co-working brain, one phase at a time. Each command does one job, shows its work before saving, and ends with a receipt line you can paste into the AI Install portal. The finished brain centers on `AGENTS.md` at the root of your `MY BIZ BRAIN` folder.

## How to use it

Open Codex, connect your `MY BIZ BRAIN` folder, and mention a skill by name in a fresh conversation.

## Commands

- `$apply-updates`: Apply weekly updates
- `$brief-setup`: Morning brief setup
- `$build-skill`: Build one custom skill
- `$check-day-1`: Day 1 completion check
- `$check-day-2`: Day 2 completion check
- `$cleanup`: Pre-index cleanup
- `$cold-test`: Cold memory test
- `$dashboard`: Weekly dashboard
- `$handoff`: Session handoff
- `$memory`: Memory system and master file
- `$phase-1-about-me`: Phase 1. About me
- `$phase-2-voice`: Phase 2. Brand voice
- `$phase-3-rules`: Phase 3. Working preferences and safety rules
- `$phase-4-content`: Phase 4. Content strategy
- `$phase-5-team`: Phase 5. Team members
- `$phase-6-project`: Phase 6. Active project
- `$ready`: Pre-work readiness check
- `$resume`: Resume the build
- `$team-pack`: Team-safe pack
- `$upkeep-setup`: Weekly upkeep setup

Run one command at a time. When a command finishes, stop and review what it created before starting the next one.
