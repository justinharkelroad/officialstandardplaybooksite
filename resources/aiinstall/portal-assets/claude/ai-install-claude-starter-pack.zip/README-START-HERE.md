# The Agency AI Install: Claude Starter Pack

Welcome. This pack gives your brain a head start so build time is build time.

## Four starter-pack setup steps

1. Create your workspace folder on your computer if you have not already. Use the name `MY BIZ BRAIN` so the workshop room moves together.
2. Copy everything in this pack INTO that folder, keeping the structure:
   - `memory/glossary.md` goes in a `memory` folder
   - `current-projects/_project-template.md` goes in a `current-projects` folder
   - `working-preferences-STARTER.md` and `CLAUDE-STARTER.md` sit at the root
   - `STANDARD-SKILLS`, `INSTALL-STANDARD-SKILLS.md`, and `install-standard-skills.py` also sit at the root
3. Add your gathered materials. A `gathered-materials` folder inside `MY BIZ BRAIN` is fine. Put your writing samples, team roster, project list, and agency facts there. For tools, create one simple Word, text, or Markdown list naming each paid tool and what you use it for. Screenshots are not needed.
4. Open `MY BIZ BRAIN` in Cowork, make sure the starter-pack files appear, then tell Claude: **Read `INSTALL-STANDARD-SKILLS.md` and complete the installation for Claude.** Wait for `SKILLS-INSTALLED.md` to say `5/5 skills passed`.

These are the four starter-pack setup steps. They are not the full readiness checklist. Return to the [Claude pre-work page](https://standardplaybook.com/aiinstall/prework/claude), run the install-and-`READY.txt` test, and complete all six checks under **Final check**.

## Required final screenshot

After all six checks are complete, take one screenshot showing `MY BIZ BRAIN` open inside Cowork with `READY.txt` visible. Submit it through the [pre-work confirmation form](https://standardplaybook.com/aiinstall/ready) as soon as your setup is complete. Do not email the screenshot unless Mary asks you to.

## What NOT to do

- Do not fill the starter files in by hand. We do that together, live, with the brain doing the typing.
- Do not rename the starter files. The workshop prompts reference them by name.
- Do not edit the files inside `STANDARD-SKILLS`. The installed copies are versioned and validated together.
- Do not put raw exports or data dumps in the folder. Exports stay outside the brain; it points at them when it needs to analyze them.
- Do not put passwords, account keys, API keys, or login credentials in the folder.

## What is in the pack

| File | What it is |
|---|---|
| `CLAUDE-STARTER.md` | The skeleton of your master file. Becomes `CLAUDE.md` in Phase 7. |
| `working-preferences-STARTER.md` | Your rules of engagement, with the four safety rules pre-written. Customized in Phase 3. |
| `memory/glossary.md` | About 30 insurance terms, pre-loaded. You cut, correct, and add in Phase 7. |
| `current-projects/_project-template.md` | The shape of a project file. Phase 6 builds your real ones from it. |
| `STANDARD-SKILLS/` | Five local agency-report skills plus their shared analyzer. |
| `INSTALL-STANDARD-SKILLS.md` | The one-time installation instruction for Cowork. |
| `install-standard-skills.py` | The local installer and 5/5 validation receipt builder. |
| `STANDARD-AGENCY-INTELLIGENCE-GUIDE.md` | What each skill does, the reports it uses, and copy-paste starter requests. |

See you in the room.
