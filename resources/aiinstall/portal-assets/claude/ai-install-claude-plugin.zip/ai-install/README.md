# AI Install

AI Install v2.0.0 walks an insurance agency owner through building an AI co-working brain, one phase at a time. Each command does one job, shows its work before saving, and ends with a receipt line you can paste into the AI Install portal. The finished brain centers on `CLAUDE.md` at the root of your `MY BIZ BRAIN` folder.

## How to use it

Open Cowork, connect your `MY BIZ BRAIN` folder, and type a command in a fresh conversation.

## Commands

- `/ai-install:apply-updates`: Apply weekly updates
- `/ai-install:brief-setup`: Morning brief setup
- `/ai-install:build-skill`: Build one custom skill
- `/ai-install:check-day-1`: Day 1 completion check
- `/ai-install:check-day-2`: Day 2 completion check
- `/ai-install:cleanup`: Pre-index cleanup
- `/ai-install:cold-test`: Cold memory test
- `/ai-install:dashboard`: Weekly dashboard
- `/ai-install:handoff`: Session handoff
- `/ai-install:memory`: Memory system and master file
- `/ai-install:phase-1-about-me`: Phase 1. About me
- `/ai-install:phase-2-voice`: Phase 2. Brand voice
- `/ai-install:phase-3-rules`: Phase 3. Working preferences and safety rules
- `/ai-install:phase-4-content`: Phase 4. Content strategy
- `/ai-install:phase-5-team`: Phase 5. Team members
- `/ai-install:phase-6-project`: Phase 6. Active project
- `/ai-install:ready`: Pre-work readiness check
- `/ai-install:resume`: Resume the build
- `/ai-install:team-pack`: Team-safe pack
- `/ai-install:upkeep-setup`: Weekly upkeep setup

Run one command at a time. When a command finishes, stop and review what it created before starting the next one.
