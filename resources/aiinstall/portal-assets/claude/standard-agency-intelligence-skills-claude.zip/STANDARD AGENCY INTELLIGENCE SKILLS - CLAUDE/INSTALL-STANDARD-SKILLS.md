# Install the Standard Agency Intelligence Skills for Claude/Cowork

This is a one-time, project-local installation for an existing `MY BIZ BRAIN`. Do not rename or rebuild the project. Do not change its existing instructions, memory, preferences, or project files.

## Instruction for Claude/Cowork

> Install all five Standard Agency Intelligence skills from the `STANDARD-SKILLS` folder into this existing `MY BIZ BRAIN` project for Claude/Cowork. Run `python3 install-standard-skills.py --platform claude` from the project root. If that Python command is unavailable, try the available Python interpreter with the same script and `--platform claude`. If no Python interpreter is available, stop and explain that the validated installer could not run. Do not manually overwrite any skill folder. Do not create or change `CLAUDE.md`, memory, preferences, or project files. Do not upload, move, or alter any source agency report.

The validated installer writes only the five Standard skills and their shared analyzer to `.claude/skills`, then creates `SKILLS-INSTALLED.md` in the project root.

Installation is complete only when `SKILLS-INSTALLED.md` says `5/5 skills passed`.

If the Standard skills were installed previously, the installer stops without changing them. Do not use `--replace` unless the owner intentionally requests a pack update. A replacement backs up the previous Standard skill folders and receipt before installing the new copies.

## Safety boundary

- Keep source exports outside `MY BIZ BRAIN`; point the appropriate skill at them when needed.
- Nothing sends to staff, clients, or prospects without the agency owner's explicit approval.
- Never treat a commission exception as proof of underpayment without the governing carrier schedule.
- Never confirm coverage, quote a rate, bind a policy, or change pricing, commission, or compensation.
