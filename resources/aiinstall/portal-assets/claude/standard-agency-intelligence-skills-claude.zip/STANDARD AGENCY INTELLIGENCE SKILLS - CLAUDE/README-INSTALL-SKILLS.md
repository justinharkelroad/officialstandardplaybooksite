# Add the Standard Agency Intelligence Skills to Claude/Cowork

This is a skills-only add-on for an existing `MY BIZ BRAIN`. It does not create, rename, replace, or rebuild your Biz Brain.

## Install once

1. Download and unzip this Claude/Cowork skills package.
2. Open the extracted package. It should contain this README plus:
   - `STANDARD-SKILLS`
   - `INSTALL-STANDARD-SKILLS.md`
   - `install-standard-skills.py`
   - `STANDARD-AGENCY-INTELLIGENCE-GUIDE.md`
   If any of these names already exists in your `MY BIZ BRAIN`, stop and ask for update instructions before replacing anything.
3. Copy all five items into the root of your existing `MY BIZ BRAIN` folder.
4. Open that existing `MY BIZ BRAIN` folder in Claude/Cowork.
5. Send Claude:

   > Read `INSTALL-STANDARD-SKILLS.md` and complete the one-time installation for Claude in this existing `MY BIZ BRAIN`. Do not change any of my existing instructions, memory, preferences, or project files.

6. Wait for `SKILLS-INSTALLED.md` to appear and confirm it says `5/5 skills passed`.

If validation does not say `5/5 skills passed`, stop and share a screenshot of the error. Do not copy skill folders into hidden locations manually.

## Use the skills

Keep raw agency reports outside `MY BIZ BRAIN`. When you want to analyze one:

1. Open your existing `MY BIZ BRAIN` folder in Claude/Cowork.
2. Start a new task.
3. Attach the report or point Claude to its local file path.
4. Send:

   > Analyze this report with the appropriate Standard Agency Intelligence skill. Create the owner dashboard and local working list, explain the three most important findings, and do not send or change anything.

The skills install once and remain available in this project.

## What this package will not change

- Your existing `CLAUDE.md`
- Your memory or glossary
- Your working preferences
- Your current projects
- Your source agency reports

Read `STANDARD-AGENCY-INTELLIGENCE-GUIDE.md` for the five skills, supported reports, outputs, starter requests, and limitations.
